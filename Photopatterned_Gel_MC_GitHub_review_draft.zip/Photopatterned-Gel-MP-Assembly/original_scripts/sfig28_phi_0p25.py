import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import time

# 模拟参数
N = 800  # 粒子数
d = 1.0  # 粒子直径
L = 50.0  # 盒子边长
steps = 30000  # 总 MC 步数
snapshot_steps = list(range(0, 30001, 1000))  # 每 1000 步输出
lambda_m = 4.5  # 粒子-粒子相互作用强度
xi = 80.0  # 粒子-磁场相互作用
r_c = 1.2 * d  # 簇形成距离阈值
r_coff = 10.0 * d  # 相互作用截断半径
delta_r = 0.5 * d  # 最大位移
delta_theta = np.deg2rad(10)  # 最大角度变化
cluster_move_freq = 70  # 每 70 步执行簇移动
epsilon = 1e-6  # 最小距离阈值
repulsive_energy = 1e6  # 硬球排斥能量
max_attempts = 20000  # 增加尝试次数

# 计算体积分数
phi = N * np.pi * (d / 2)**2 / L**2
print(f"体积分数 (填充体数): {phi:.5f}")

# 定义活动区域（4 个方块）
ranges = [[10, 20], [30, 40]]
active_zones = [(x_range, y_range) for x_range in ranges for y_range in ranges]

# 检查粒子是否在活动区域内
def is_in_active_zone(pos):
    x, y = pos
    for x_range, y_range in active_zones:
        if x_range[0] <= x <= x_range[1] and y_range[0] <= y <= y_range[1]:
            return True
    return False

# 初始化随机非重叠粒子位置
def initialize_positions(N, L, d):
    np.random.seed(42)
    positions = np.zeros((N, 2))
    positions[0] = np.random.uniform(0, L, 2)
    for i in range(1, N):
        placed = False
        attempts = 0
        while not placed and attempts < max_attempts:
            new_pos = np.random.uniform(0, L, 2)
            valid = True
            for j in range(i):
                r_vec = new_pos - positions[j]
                r, _ = periodic_distance(r_vec, L)
                if r < d:
                    valid = False
                    break
            if valid:
                positions[i] = new_pos
                placed = True
            attempts += 1
        if not placed:
            raise ValueError(f"无法在 {max_attempts} 次尝试后放置第 {i+1} 个粒子，考虑减少 N 或增加 L")
    return positions

# 计算周期性边界条件下的距离
def periodic_distance(r_vec, L):
    r_vec = r_vec - L * np.round(r_vec / L)
    r = np.sqrt(np.sum(r_vec**2))
    return r, r_vec

# 构建邻居列表
def build_neighbor_list(positions, L, r_coff):
    neighbor_list = [[] for _ in range(N)]
    for i in range(N):
        for j in range(i + 1, N):
            r_vec = positions[j] - positions[i]
            r, _ = periodic_distance(r_vec, L)
            if r < r_coff:
                neighbor_list[i].append(j)
                neighbor_list[j].append(i)
    return neighbor_list

# 计算单粒子对系统的能量贡献（增量更新）
def compute_particle_energy(i, positions, dipoles, H, neighbor_list):
    energy = -xi * np.dot(dipoles[i], H)  # 粒子-磁场相互作用
    for j in neighbor_list[i]:
        r_vec = positions[j] - positions[i]
        r, r_vec = periodic_distance(r_vec, L)
        if r < epsilon:
            return float('inf')
        if r < d:
            energy += repulsive_energy
        if r < r_coff:
            r_hat = r_vec / r
            n_i = dipoles[i]
            n_j = dipoles[j]
            energy += lambda_m * (d / r)**3 * (np.dot(n_i, n_j) - 3 * np.dot(n_i, r_hat) * np.dot(n_j, r_hat))
    return energy

# 计算总能量（仅用于初始化或簇移动）
def compute_total_energy(positions, dipoles, H, neighbor_list):
    energy = 0.0
    for i in range(N):
        energy += compute_particle_energy(i, positions, dipoles, H, neighbor_list)
    return energy / 2  # 避免双重计数粒子对

# 识别簇
def identify_clusters(positions, is_active):
    clusters = []
    visited = set()
    for i in range(N):
        if i not in visited and is_active[i]:
            cluster = [i]
            visited.add(i)
            stack = [i]
            while stack:
                current = stack.pop()
                for j in range(N):
                    if j not in visited and is_active[j]:
                        r_vec = positions[j] - positions[current]
                        r, _ = periodic_distance(r_vec, L)
                        if r < r_c:
                            cluster.append(j)
                            visited.add(j)
                            stack.append(j)
            clusters.append(cluster)
    return clusters

# 初始化粒子
start_time = time.time()
positions = initialize_positions(N, L, d)
dipoles = np.array([[1.0, 0.0] for _ in range(N)])
is_active = np.array([is_in_active_zone(pos) for pos in positions])
print(f"活动区域粒子数: {sum(is_active)}")
print(f"初始化耗时: {time.time() - start_time:.2f} 秒")

# 构建初始邻居列表
neighbor_list = build_neighbor_list(positions, L, r_coff)

# 蒙特卡洛步
H = np.array([1.0, 0.0])
trajectories = []
excel_data = []
energy = compute_total_energy(positions, dipoles, H, neighbor_list)
neighbor_update_freq = 100  # 每 100 步更新邻居列表
start_time = time.time()

for step in range(steps + 1):
    if step % neighbor_update_freq == 0:
        neighbor_list = build_neighbor_list(positions, L, r_coff)

    if step % cluster_move_freq == 0 and step > 0:
        # 簇移动
        clusters = identify_clusters(positions, is_active)
        for cluster in clusters:
            if all(is_active[i] for i in cluster):
                delta_pos = np.random.uniform(-delta_r, delta_r, (2,))
                new_positions = positions.copy()
                valid_move = True
                for i in cluster:
                    new_pos = new_positions[i] + delta_pos
                    new_pos %= L
                    if not is_in_active_zone(new_pos):
                        valid_move = False
                        break
                if valid_move:
                    old_energy = sum(compute_particle_energy(i, positions, dipoles, H, neighbor_list) for i in cluster)
                    for i in cluster:
                        new_positions[i] = (new_positions[i] + delta_pos) % L
                    new_energy = sum(compute_particle_energy(i, new_positions, dipoles, H, neighbor_list) for i in cluster)
                    if new_energy <= old_energy or np.random.rand() < np.exp(-(new_energy - old_energy)):
                        positions = new_positions
                        energy += new_energy - old_energy
                    # 邻居列表在下次更新

    else:
        # 单粒子移动
        i = np.random.randint(N)
        if is_active[i]:
            old_pos = positions[i].copy()
            old_dipole = dipoles[i].copy()
            old_energy = compute_particle_energy(i, positions, dipoles, H, neighbor_list)

            positions[i] += np.random.uniform(-delta_r, delta_r, (2,))
            positions[i] %= L
            if not is_in_active_zone(positions[i]):
                positions[i] = old_pos
                continue
            theta = np.arctan2(dipoles[i, 1], dipoles[i, 0]) + np.random.uniform(-delta_theta, delta_theta)
            dipoles[i] = np.array([np.cos(theta), np.sin(theta)])

            new_energy = compute_particle_energy(i, positions, dipoles, H, neighbor_list)
            if new_energy > old_energy and np.random.rand() >= np.exp(-(new_energy - old_energy)):
                positions[i] = old_pos
                dipoles[i] = old_dipole
            else:
                energy += new_energy - old_energy

    # 保存快照和坐标
    if step in snapshot_steps:
        trajectories.append(positions.copy())
        active_mask = is_active
        inactive_mask = ~is_active
        df_active = pd.DataFrame({
            'Particle': np.arange(N)[active_mask],
            'X': positions[active_mask, 0],
            'Y': positions[active_mask, 1]
        })
        df_inactive = pd.DataFrame({
            'Particle': np.arange(N)[inactive_mask],
            'X': positions[inactive_mask, 0],
            'Y': positions[inactive_mask, 1]
        })
        excel_data.append((step, df_active, df_inactive))
        print(f"保存快照于步骤 {step}, trajectories 长度: {len(trajectories)}")

# 验证 trajectories 和 snapshot_steps 一致性
if len(trajectories) != len(snapshot_steps):
    print(f"警告: trajectories 长度 ({len(trajectories)}) 不等于 snapshot_steps 长度 ({len(snapshot_steps)})")
else:
    print(f"trajectories 长度验证通过: {len(trajectories)}")

# 输出快照和 Excel
for i, step in enumerate(snapshot_steps):
    if i >= len(trajectories):
        print(f"错误: 无法访问 trajectories[{i}]，快照不足，跳过步骤 {step}")
        continue
    plt.figure(figsize=(6, 6))
    active_positions = trajectories[i][is_active]
    inactive_positions = trajectories[i][~is_active]
    if len(active_positions) > 0:
        plt.scatter(active_positions[:, 0], active_positions[:, 1], s=50, c='blue', alpha=0.6, label='Active')
    if len(inactive_positions) > 0:
        plt.scatter(inactive_positions[:, 0], inactive_positions[:, 1], s=50, c='red', alpha=0.6, label='Inactive')
    plt.xlim(0, L)
    plt.ylim(0, L)
    plt.title(f'Snapshot at Step {step}')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.legend()
    plt.grid(True)
    plt.savefig(f'snapshot_step_{step}.png')
    plt.close()

# 保存 Excel
with pd.ExcelWriter('snapshot_coordinates.xlsx') as writer:
    for step, df_active, df_inactive in excel_data:
        pd.DataFrame([['Active Particles']]).to_excel(writer, sheet_name=f'Step_{step}', startrow=0, index=False, header=False)
        df_active.to_excel(writer, sheet_name=f'Step_{step}', startrow=1, index=False)
        startrow_inactive = len(df_active) + 3
        pd.DataFrame([['Inactive Particles']]).to_excel(writer, sheet_name=f'Step_{step}', startrow=startrow_inactive, index=False, header=False)
        df_inactive.to_excel(writer, sheet_name=f'Step_{step}', startrow=startrow_inactive + 1, index=False)

print(f"模拟完成。总耗时: {time.time() - start_time:.2f} 秒。快照已保存为 PNG 文件。坐标已保存至 snapshot_coordinates.xlsx")