"""Execute one original simulation in its own outputs/ directory.

Usage:
    python run.py --list
    python run.py sfig24 --dry-run
    python run.py sfig24
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASES = {
    "movie1": "supplementary_movie_1.py",
    "sfig24": "sfig24_phi_0p015.py",
    "sfig25": "sfig25_phi_0p031.py",
    "sfig26": "sfig26_phi_0p062.py",
    "sfig27": "sfig27_phi_0p125.py",
    "sfig28": "sfig28_phi_0p25.py",
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run an original magnetic-particle Monte Carlo simulation")
    parser.add_argument("case", nargs="?", choices=sorted(CASES), help="Case to run")
    parser.add_argument("--list", action="store_true", help="List cases without running")
    parser.add_argument("--dry-run", action="store_true", help="Show the command without executing")
    args = parser.parse_args()

    if args.list or args.case is None:
        for label, filename in CASES.items():
            print(f"{label:7s} original_scripts/{filename}")
        return

    script = ROOT / "original_scripts" / CASES[args.case]
    output_dir = ROOT / "outputs" / args.case
    cmd = [sys.executable, str(script)]
    print(f"Case: {args.case}")
    print(f"Script: {script}")
    print(f"Output directory: {output_dir}")
    if args.dry_run:
        print("Dry run: simulation not executed.")
        return

    output_dir.mkdir(parents=True, exist_ok=True)
    print("Running original script; this may be slow and produce many PNG files...", flush=True)
    subprocess.run(cmd, cwd=output_dir, check=True)


if __name__ == "__main__":
    main()
