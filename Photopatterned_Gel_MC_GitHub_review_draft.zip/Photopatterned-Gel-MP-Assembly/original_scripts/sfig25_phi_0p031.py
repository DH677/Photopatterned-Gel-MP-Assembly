import numpy as np
import matplotlib.pyplot as plt
from IPython.display import display, clear_output
import time
import pandas as pd

# 模拟参数
N = 100  # 粒子数
d = 1.0  # 粒子直径
L = 50.0  # 盒子边长，大方格 [0, 50]
steps = 30000  # 总 MC 步数
snapshot_steps = list(range(0, 30001, 1000))  # 每 1000 步输出
lambda_m = 4.5  # 粒子-粒子相互作用强度 (Satoh et al.)
xi = 80.0  # 粒子-磁场相互作用强度 (Peng et al.)
r_c = 1.2 * d  # 簇形成距离阈值
r_coff = 10.0 * d  # 相互作用截断半径
delta_r = 0.5 * d  # 最大位移
delta_theta = np.deg2rad(10)  # 最大角度变化
cluster_move_freq = 70  # 每 70 步执行簇移动
epsilon = 1e-6  # 最小距离阈值，防止除零
repulsive_energy = 1e6  # 硬球排斥能量惩罚
max_attempts = 10000  # 拒绝采样的最大尝试次数

# 计算体积分数
phi = N * np.pi * (d / 2)**2 / L**2
print(f"体积分数 (填充体数): {phi:.5f}")

# 定义活动区域（4 个方块）
ranges = [[10, 20], [30, 40]]  # x 和 y 范围
active_zones = [(x_range, y_range) for x_range in ranges for y_range in ranges]

# 检查粒子是否在活动区域内
def is_in_active_zone(pos):
    x, y = pos
    for x_range, y_range in active_zones:
        if x_range[0] <= x <= x_range[1] and y_range[0] <= y <= y_range[1]:
            return True
    return False

# 初始化随机非重叠粒子位置
def initialize_positions(N, L, d):
    np.random.seed(42)
    positions = np.zeros((N, 2))
    positions[0] = np.random.uniform(0, L, 2)  # 第一个粒子随机放置
    for i in range(1, N):
        placed = False
        attempts = 0
        while not placed and attempts < max_attempts:
            new_pos = np.random.uniform(0, L, 2)
            valid = True
            for j in range(i):
                r_vec = new_pos - positions[j]
                r, _ = periodic_distance(r_vec, L)
                if r < d:
                    valid = False
                    break
            if valid:
                positions[i] = new_pos
                placed = True
            attempts += 1
        if not placed:
            raise ValueError(f"无法在 {max_attempts} 次尝试后放置第 {i+1} 个粒子，考虑减少 N 或增加 L")
    return positions

# 计算周期性边界条件下的距离
def periodic_distance(r_vec, L):
    r_vec = r_vec - L * np.round(r_vec / L)  # 最小镜像距离
    r = np.sqrt(np.sum(r_vec**2))
    return r, r_vec

# 计算总能量
def compute_energy(positions, dipoles, H):
    energy = 0.0
    for i in range(N):
        # 粒子-磁场相互作用
        energy += -xi * np.dot(dipoles[i], H)
        for j in range(i + 1, N):
            r_vec = positions[j] - positions[i]
            r, r_vec = periodic_distance(r_vec, L)
            if r < epsilon:
                return float('inf')  # 防止除零，能量设为无穷大
            if r < d:
                energy += repulsive_energy  # 硬球排斥
            if r < r_coff:
                r_hat = r_vec / r
                n_i = dipoles[i]
                n_j = dipoles[j]
                # 粒子-粒子相互作用
                energy += lambda_m * (d / r)**3 * (np.dot(n_i, n_j) - 3 * np.dot(n_i, r_hat) * np.dot(n_j, r_hat))
    return energy

# 识别簇
def identify_clusters(positions, is_active):
    clusters = []
    visited = set()
    for i in range(N):
        if i not in visited and is_active[i]:
            cluster = [i]
            visited.add(i)
            stack = [i]
            while stack:
                current = stack.pop()
                for j in range(N):
                    if j not in visited and is_active[j]:
                        r_vec = positions[j] - positions[current]
                        r, _ = periodic_distance(r_vec, L)
                        if r < r_c:
                            cluster.append(j)
                            visited.add(j)
                            stack.append(j)
            clusters.append(cluster)
    return clusters

# 初始化粒子
positions = initialize_positions(N, L, d)
dipoles = np.array([[1.0, 0.0] for _ in range(N)])  # 磁偶极子沿 x 轴（磁场方向）
is_active = np.array([is_in_active_zone(pos) for pos in positions])

# 蒙特卡洛步
H = np.array([1.0, 0.0])  # 磁场沿 x 轴
trajectories = []
excel_data = []
energy = compute_energy(positions, dipoles, H)
for step in range(steps + 1):
    if step % cluster_move_freq == 0 and step > 0:
        # 簇移动
        clusters = identify_clusters(positions, is_active)
        for cluster in clusters:
            if all(is_active[i] for i in cluster):
                delta_pos = np.random.uniform(-delta_r, delta_r, (2,))
                new_positions = positions.copy()
                valid_move = True
                for i in cluster:
                    new_pos = new_positions[i] + delta_pos
                    new_pos %= L  # 周期性边界
                    if not is_in_active_zone(new_pos):
                        valid_move = False
                        break
                if valid_move:
                    for i in cluster:
                        new_positions[i] = new_pos
                    new_energy = compute_energy(new_positions, dipoles, H)
                    if new_energy <= energy or np.random.rand() < np.exp(-(new_energy - energy)):
                        positions = new_positions
                        energy = new_energy
    else:
        # 单粒子移动
        i = np.random.randint(N)
        if is_active[i]:
            old_pos = positions[i].copy()
            old_dipole = dipoles[i].copy()
            positions[i] += np.random.uniform(-delta_r, delta_r, (2,))
            positions[i] %= L
            if not is_in_active_zone(positions[i]):
                positions[i] = old_pos
                continue
            theta = np.arctan2(dipoles[i, 1], dipoles[i, 0]) + np.random.uniform(-delta_theta, delta_theta)
            dipoles[i] = np.array([np.cos(theta), np.sin(theta)])
            new_energy = compute_energy(positions, dipoles, H)
            if new_energy > energy and np.random.rand() >= np.exp(-(new_energy - energy)):
                positions[i] = old_pos
                dipoles[i] = old_dipole
            else:
                energy = new_energy

    # 保存快照和坐标
    if step in snapshot_steps:
        trajectories.append(positions.copy())
        # 分离 Active 和 Inactive 粒子
        active_mask = is_active
        inactive_mask = ~is_active
        df_active = pd.DataFrame({
            'Particle': np.arange(N)[active_mask],
            'X': positions[active_mask, 0],
            'Y': positions[active_mask, 1]
        })
        df_inactive = pd.DataFrame({
            'Particle': np.arange(N)[inactive_mask],
            'X': positions[inactive_mask, 0],
            'Y': positions[inactive_mask, 1]
        })
        excel_data.append((step, df_active, df_inactive))
    
    # 动态显示
    if step % 500 == 0:
        clear_output(wait=True)
        plt.figure(figsize=(6, 6))
        active_positions = positions[is_active]
        inactive_positions = positions[~is_active]
        if len(active_positions) > 0:
            plt.scatter(active_positions[:, 0], active_positions[:, 1], s=50, c='blue', alpha=0.6, label='Active')
        if len(inactive_positions) > 0:
            plt.scatter(inactive_positions[:, 0], inactive_positions[:, 1], s=50, c='red', alpha=0.6, label='Inactive')
        plt.xlim(0, L)
        plt.ylim(0, L)
        plt.title(f'Step {step}')
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.legend()
        plt.grid(True)
        display(plt.gcf())
        plt.close()
        time.sleep(0.1)

# 输出快照和 Excel
for i, step in enumerate(snapshot_steps):
    plt.figure(figsize=(6, 6))
    active_positions = trajectories[i][is_active]
    inactive_positions = trajectories[i][~is_active]
    if len(active_positions) > 0:
        plt.scatter(active_positions[:, 0], active_positions[:, 1], s=50, c='blue', alpha=0.6, label='Active')
    if len(inactive_positions) > 0:
        plt.scatter(inactive_positions[:, 0], inactive_positions[:, 1], s=50, c='red', alpha=0.6, label='Inactive')
    plt.xlim(0, L)
    plt.ylim(0, L)
    plt.title(f'Snapshot at Step {step}')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.legend()
    plt.grid(True)
    plt.savefig(f'snapshot_step_{step}.png')
    plt.close()

# 保存 Excel
with pd.ExcelWriter('snapshot_coordinates.xlsx') as writer:
    for step, df_active, df_inactive in excel_data:
        # 写入 Active 粒子
        pd.DataFrame([['Active Particles']]).to_excel(writer, sheet_name=f'Step_{step}', startrow=0, index=False, header=False)
        df_active.to_excel(writer, sheet_name=f'Step_{step}', startrow=1, index=False)
        # 写入 Inactive 粒子（在 Active 之后，留空行）
        startrow_inactive = len(df_active) + 3  # Active 数据长度 + 标题行 + 空行
        pd.DataFrame([['Inactive Particles']]).to_excel(writer, sheet_name=f'Step_{step}', startrow=startrow_inactive, index=False, header=False)
        df_inactive.to_excel(writer, sheet_name=f'Step_{step}', startrow=startrow_inactive + 1, index=False)

print("模拟完成。快照已保存为 PNG 文件。坐标已保存至 snapshot_coordinates.xlsx")